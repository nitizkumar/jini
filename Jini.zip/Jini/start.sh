java -jar Jini.one-jar.jar
